function scrollToShop(){
document.getElementById("shop").scrollIntoView({
behavior:"smooth"
});
}